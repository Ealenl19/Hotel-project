package com.tus.athlone.hotel.models;

public enum RoomType {

	Standard, Balcony, Delux, Suit
}
